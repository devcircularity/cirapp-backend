// server/controllers/userController.js
const User = require('../models/userModel'); // Replace with your actual User Mongoose model

exports.addUser = async (req, res) => {
  try {
    const newUser = new User(req.body);
    await newUser.save();
    res.status(201).json(newUser);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
